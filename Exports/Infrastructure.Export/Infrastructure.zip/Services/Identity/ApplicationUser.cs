﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Services.Identity
{
    public class ApplicationUser: IdentityUser
    {
    }
}
